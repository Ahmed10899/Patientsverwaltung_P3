// Paket für die Patientenverwaltung
package view;

// Importieren von erforderlichen Java-Klassen und Swing-Komponenten
import view.Menu;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;

// Die Klasse "Fenster" erbt von JFrame
public class Fenster extends JFrame {
    // Instanz der Menuklasse
    Menu ES = new Menu();

    // Konstruktor für die Fensterklasse
    public Fenster() {
        // Setzen des Fenstertitels
        super("PATIENTEN_VERWALTUNG");

        // Einstellungen für das Fenster
        this.setSize(1250, 620);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setBackground(Color.GRAY);

        // Hinzufügen des Home-Panels und des Menüs zum Fenster
        this.add(ES.H, BorderLayout.CENTER);
        this.add(ES, BorderLayout.EAST);
    }
}
