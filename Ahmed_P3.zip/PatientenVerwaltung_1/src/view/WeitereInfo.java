/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author Dell
 */
import java.awt.Color;
import java.awt.Font;
import java.util.UUID;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class WeitereInfo extends JPanel{

	JLabel heading = new JLabel("Wer bin ich !");
	
	JLabel Nachname = new JLabel("Nachname: Tarek");
	JLabel Vorname = new JLabel("Vorname: Ahmed");
	JLabel Matrikelnummer = new JLabel("Matrikelnummer: 6047981");
        
      
        
	JLabel Studiengang = new JLabel("Studiengang: Wirtschaftsinformatik");
	JLabel Hochschule = new JLabel("Hochschule: Jade Hochschule");

	
	public WeitereInfo()
	{
		
				
		heading.setFont(new Font("Roboto",Font.BOLD,28));
		heading.setBounds(300,0,400,100);
		
                Nachname.setFont(new Font("Roboto",Font.BOLD,16));
		Nachname.setBounds(100,100,400,100);
		

                
		Vorname.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Vorname.setBounds(100,130,400,100);
		
		
		Matrikelnummer.setFont(new Font("Roboto",Font.ROMAN_BASELINE,16));
		Matrikelnummer.setBounds(100,160,400,100);
                
               
		
               
                
                
		
		Studiengang.setFont(new Font("Roboto",Font.BOLD,16));
		Studiengang.setBounds(100,550,400,100);

		Hochschule.setFont(new Font("Roboto",Font.BOLD,16));
		Hochschule.setBounds(100,580,400,100);

		


		

		setBackground(Color.WHITE);
		setLayout(null);
		add(heading);
		add(Nachname);
		add(Vorname);
		add(Matrikelnummer);
                
		add(Studiengang);
		add(Hochschule);
	

	

	}

   

   
}
    

