// Paket für die Patientenverwaltung
package view;

// Importieren von erforderlichen Java-Klassen und Swing-Komponenten
import PatientenVerwaltung.Home;
import PatientenVerwaltung.Patienten;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JPanel;

// Die Klasse "Menu" erbt von JPanel
public class Menu extends JPanel{
    
    // Deklaration der Labels für die Menüpunkte
    JLabel labelListe = new JLabel("Home");
    JLabel labelPatient = new JLabel("Patienten Liste");
    JLabel labelPatientSuchen = new JLabel("Patienten Suchen");
    JLabel labelWeitereInfo = new JLabel("Info");

    // Instanzen der Patienten- und Home-Klassen
    Patienten A = new Patienten();
    Home H = new Home();
PatientenSuche S = new PatientenSuche(A);
WeitereInfo W = new WeitereInfo();
    // Konstruktor für die Menuklasse
    public Menu() {
        setLayout(null);
        setPreferredSize(new Dimension(240, 100));
        setBackground(Color.RED);

        // Einstellungen für das Label "Home"
        labelListe.setFont(new Font("Arial", Font.BOLD, 15));
        labelListe.setBounds(20, 100, 100, 100);
        labelListe.setForeground(Color.WHITE);
        labelListe.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Einstellungen für das Label "Patienten Liste"
        labelPatient.setFont(new Font("Arial", Font.BOLD, 15));
        labelPatient.setBounds(20, 150, 250, 100);
        labelPatient.setForeground(Color.WHITE);
        labelPatient.setCursor(new Cursor(Cursor.HAND_CURSOR));

         // Einstellungen für das Label "Patienten Suchen"
        labelPatientSuchen.setFont(new Font("Arial", Font.BOLD, 15));
        labelPatientSuchen.setBounds(20, 200, 400, 100);
        labelPatientSuchen.setForeground(Color.WHITE);
        labelPatientSuchen.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
         // Einstellungen für das Label "WeitereInfo"
        labelWeitereInfo.setFont(new Font("Arial", Font.BOLD, 15));
        labelWeitereInfo.setBounds(20, 250, 550, 100);
        labelWeitereInfo.setForeground(Color.WHITE);
        labelWeitereInfo.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hinzufügen der Labels zum Panel
        add(labelListe);
        add(labelPatient);
add(labelPatientSuchen);
add(labelWeitereInfo);

        // Hinzufügen von MouseListener für die Labels
        labelListe.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Aufrufen der Methode ErstellHome() beim Klick auf das Label "Home"
                ErstellHome();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // Ändern der Textfarbe beim Drücken des Labels
                labelListe.setForeground(Color.yellow);
                labelPatient.setForeground(Color.white);
            }

            @Override
            public void mouseReleased(MouseEvent e) {}

            @Override
            public void mouseEntered(MouseEvent e) {}

            @Override
            public void mouseExited(MouseEvent e) {}
        });

        labelPatient.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Aufrufen der Methode ErstellPatient() beim Klick auf das Label "Patienten Liste"
                ErstellPatient();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // Ändern der Textfarbe beim Drücken des Labels
                labelPatient.setForeground(Color.orange);
                labelListe.setForeground(Color.white);
            }

            @Override
            public void mouseReleased(MouseEvent e) {}

            @Override
            public void mouseEntered(MouseEvent e) {}

            @Override
            public void mouseExited(MouseEvent e) {}
        });
        labelPatientSuchen.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Aufrufen der Methode ErstellPatient() beim Klick auf das Label "Patienten Liste"
                ErstellPatientSuchen();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // Ändern der Textfarbe beim Drücken des Labels
                labelPatientSuchen.setForeground(Color.blue);
                labelPatientSuchen.setForeground(Color.white);
            }

            @Override
            public void mouseReleased(MouseEvent e) {}

            @Override
            public void mouseEntered(MouseEvent e) {}

            @Override
            public void mouseExited(MouseEvent e) {}
        });
         labelWeitereInfo.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Aufrufen der Methode ErstellPatient() beim Klick auf das Label "Patienten Liste"
                ErstellWeitereInfo();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // Ändern der Textfarbe beim Drücken des Labels
                labelWeitereInfo.setForeground(Color.gray);
                labelWeitereInfo.setForeground(Color.white);
            }

            @Override
            public void mouseReleased(MouseEvent e) {}

            @Override
            public void mouseEntered(MouseEvent e) {}

            @Override
            public void mouseExited(MouseEvent e) {}
        });
    
    
    }

  

    // Methode zum Wechseln zum Patienten-Panel und Aktualisieren der Oberfläche
    private JPanel ErstellPatient() {
        getRootPane().getContentPane().remove(H);
                        getRootPane().getContentPane().remove(S);

        getRootPane().getContentPane().add(A);
        A.revalidate();
        A.repaint();
        return A;
    }

    // Methode zum Wechseln zum Home-Panel und Aktualisieren der Oberfläche
    private JPanel ErstellHome() {
        getRootPane().getContentPane().remove(A);
                        getRootPane().getContentPane().remove(S);
                                getRootPane().getContentPane().remove(W);

        getRootPane().getContentPane().add(H);
        H.revalidate();
        H.repaint();
        return H;
    }
    
 private PatientenSuche ErstellPatientSuchen() {
        getRootPane().getContentPane().remove(A);
                getRootPane().getContentPane().remove(H);
                                getRootPane().getContentPane().remove(W);

                getRootPane().getContentPane().add(S);
        S.revalidate();
        S.repaint();
        return S;
    }
private WeitereInfo ErstellWeitereInfo() {
        getRootPane().getContentPane().remove(A);
                getRootPane().getContentPane().remove(H);
                getRootPane().getContentPane().add(W);
        W.revalidate();
        W.repaint();
        return W;
    }

}
