// Paket für die Patientenverwaltung
package PatientenVerwaltung;

// Importieren von erforderlichen Java-Klassen und Swing-Komponenten
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.FlowLayout;

// Die Klasse "Home" erbt von JPanel
public class Home extends JPanel {
    // JLabel für das Hintergrundbild
    JLabel homeimage = new JLabel(new ImageIcon("images/patienten.jpg"));

    // Konstruktor für die Homeklasse
    public Home() {
        // Verwenden eines FlowLayouts, um die Größe des Bildes zu steuern
        setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));

        // Hinzufügen des Hintergrundbilds zum Panel
        add(homeimage);
    }

    // Überschreiben der Methode getPreferredSize, um die bevorzugte Größe des Panels zu steuern
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(500, 500); // Beispielgröße, entsprechend ändern
    }
}
