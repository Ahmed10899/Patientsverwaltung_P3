
package Database;

/**
 *
 * @author Dell
 */
public class PatientenInfo {

  
    private String Vorname;
    private String Nachname;
    public int alter;
    private double gewicht;
    public String bluttype;
    public String geschlecht;
    public String privatVersichert;
    public String adresse ;
    
  public PatientenInfo(String Vorname, String Nachname, int alter, double gewicht, String bluttype,String geschlecht, String adresse,String privatVersichert) {
        this.Vorname = Vorname;
        this.Nachname = Nachname;
        this.alter = alter;
        this.gewicht = gewicht;
        this.bluttype = bluttype;
        this.geschlecht = geschlecht;
        this.adresse = adresse;
        this.privatVersichert = privatVersichert;
    }

    
    public String getVorname() {
        return Vorname;
    }

    public void setVorname(String Vorname) {
        this.Vorname = Vorname;
    }

    public String getNachname() {
        return Nachname;
    }

    public void setNachname(String Nachname) {
        this.Nachname = Nachname;
    }

    public double getGewicht() {
        return gewicht;
    }

    public void setGewicht(double gewicht) {
        this.gewicht = gewicht;
    }

    public int getAlter() {
        return alter;
    }

    public void setAlter(int alter) {
        this.alter = alter;
    }
    
     public String getBluttype() {
        return bluttype;
    }

    public void setBluttype(String bluttype) {
        this.bluttype = bluttype;
    }

    public String getGeschlecht() {
        return geschlecht;
    }

    public void setGeschlecht(String geschlecht) {
        this.geschlecht = geschlecht;
    }

    public String isPrivatVersichert() {
        return privatVersichert;
    }

    public void setPrivatVersichert(String privatVersichert) {
        this.privatVersichert = privatVersichert;
    }
    public String getPrivatVersichert()
    {
        return privatVersichert;
    }
    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

}


